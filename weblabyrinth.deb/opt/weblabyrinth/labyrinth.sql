CREATE TABLE crawlers (crawler_ip TEXT, crawler_rdns TEXT, crawler_useragent TEXT, first_seen INTEGER, last_seen INTEGER, last_alert INTEGER, num_hits INTEGER);
