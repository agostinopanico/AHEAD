#!/bin/bash

a=`grep "fi_name =" ./chain.py | cut -d\" -f 2`
echo $a
b=`grep "passwd =" ./chain.py | cut -d\' -f 2`
echo $b

> ./$a
> ./$b
