#!/usr/bin/env python

import chain
import os

os.system("./cleanup.sh")
os.system("touch " + chain.options.passwd)
chain.options.make_field()

print "Should now be initialized"
print "Run cleanup.sh to revert"

