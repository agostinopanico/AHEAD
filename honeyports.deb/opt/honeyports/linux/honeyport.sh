#!/bin/bash

echo "Started."

while [ 1 ]
do
	IP=`nc -v -l 1025 2>&1 1> /dev/null | grep from | awk '{print $3;}' | tr -d "[]"` 
	echo $IP
	iptables -A INPUT -p tcp -s $IP -j DROP
done
