#!/usr/bin/env python
import random
import hashlib
import os

mynum = ''

for i in range(100):
	mynum = str(random.randint(1,65535)) + mynum


value = hashlib.md5(mynum).hexdigest()

dbname = "."+value

COM1 = """
sqlite3 """+dbname+""" << XSS
create table requests (id text, type text, ip_address text, user_agent text, time INT(11));

XSS
"""

COM2 = """
cat index.php | sed "s/\$dbname =.*/\$dbname = '""" + dbname +  """';/g" > """+value

COM3 = """
mv """+value+""" index.php && chown www-data:www-data """ + dbname

print COM1, "\n\n", COM2, "\n\n", COM3, "\n\n", dbname

os.system(COM1)
os.system(COM2)
os.system(COM3)
